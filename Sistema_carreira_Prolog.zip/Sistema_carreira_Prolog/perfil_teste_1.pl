% Perfil: aluno com forte inclinacao para logica e dados

resposta(matematica_estatistica, 5).
resposta(logica, 5).
resposta(criatividade, 2).
resposta(analise_dados, 5).
resposta(visualizacao, 4).
resposta(design, 1).
resposta(usabilidade, 1).
resposta(detalhes, 2).
resposta(etica, 1).
resposta(investigacao, 1).
resposta(hardware, 1).
resposta(redes, 1).
resposta(resolucao_problemas, 1).
