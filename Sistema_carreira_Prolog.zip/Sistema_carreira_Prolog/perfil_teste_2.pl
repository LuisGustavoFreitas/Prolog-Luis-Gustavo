% Perfil: aluno com foco em design e experiencia do usuario

resposta(matematica_estatistica, 1).
resposta(logica, 2).
resposta(criatividade, 4).
resposta(analise_dados, 1).
resposta(visualizacao, 2).
resposta(design, 5).
resposta(usabilidade, 5).
resposta(detalhes, 2).
resposta(etica, 1).
resposta(investigacao, 1).
resposta(hardware, 1).
resposta(redes, 1).
resposta(resolucao_problemas, 1).
