% Perfil: aluno interessado em seguranca e infraestrutura

resposta(matematica_estatistica, 1).
resposta(logica, 2).
resposta(criatividade, 1).
resposta(analise_dados, 1).
resposta(visualizacao, 1).
resposta(design, 1).
resposta(usabilidade, 1).
resposta(detalhes, 5).
resposta(etica, 4).
resposta(investigacao, 5).
resposta(hardware, 5).
resposta(redes, 5).
resposta(resolucao_problemas, 4).
